/* Shared Use License: This file is owned by Derivative Inc. (Derivative)
* and can only be used, and/or modified for use, in conjunction with
* Derivative's TouchDesigner software, and only if you are a licensee who has
* accepted Derivative's TouchDesigner license or assignment agreement
* (which also govern the use of this file). You may share or redistribute
* a modified version of this file provided the following conditions are met:
*
* 1. The shared file or redistribution must retain the information set out
* above and this list of conditions.
* 2. Derivative's name (Derivative Inc.) or its trademarks may not be used
* to endorse or promote products derived from this file without specific
* prior written permission from Derivative.
*/

#pragma once

#include "CoreMinimal.h"

#include "vulkan_core.h"
#include "VulkanContext.h"

namespace UE::TouchEngine::Vulkan
{
	struct FVulkanPointers
	{
		FVulkanDynamicRHI* DynamicRHI = static_cast<FVulkanDynamicRHI*>(GDynamicRHI);
		FVulkanDevice* VulkanDevice = DynamicRHI->GetDevice();
		const VkPhysicalDevice VulkanPhysicalDeviceHandle = VulkanDevice->GetPhysicalHandle();
		const VkDevice VulkanDeviceHandle = VulkanDevice->GetInstanceHandle();
	};

	struct FVulkanContext
	{
		FVulkanCommandListContext& VulkanContext;
		FVulkanCommandBufferManager& BufferManager;
		FVulkanCmdBuffer& UploadBuffer;
			
		FVulkanContext(FRHICommandList& List)
			: VulkanContext(static_cast<FVulkanCommandListContext&>(List.GetContext()))
			, BufferManager(*VulkanContext.GetCommandBufferManager())
			, UploadBuffer(*BufferManager.GetUploadCmdBuffer())
		{}
	};

	inline uint32_t GetMemoryTypeIndex(const VkPhysicalDeviceMemoryProperties2& MemoryProperties, uint32 MemoryTypeBits, VkFlags RequirementsMask) 
	{
		for (uint32_t i = 0; i < VK_MAX_MEMORY_TYPES; i++)
		{
			if ((MemoryTypeBits & 1) == 1)
			{
				if ((MemoryProperties.memoryProperties.memoryTypes[i].propertyFlags & RequirementsMask) == RequirementsMask)
				{
					return i;
				}
			}
			MemoryTypeBits >>= 1;
		}

		return VK_MAX_MEMORY_TYPES;
	}
}